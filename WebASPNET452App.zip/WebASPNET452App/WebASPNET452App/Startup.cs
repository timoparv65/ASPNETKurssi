﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(WebASPNET452App.Startup))]
namespace WebASPNET452App
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
