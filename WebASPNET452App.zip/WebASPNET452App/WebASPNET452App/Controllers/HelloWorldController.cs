﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebASPNET452App.Controllers
{
    public class HelloWorldController : Controller
    {
        // GET: HelloWorld
        //public ActionResult Index()
        /*
        public String Index()
        {
            //return View();
            return "´This is <strong>DEFAULT INDEX</strong> Index View";
        }
        */
        /*
        public String Welcome()
        {
            return "This is welcome view";
        }
        */

        public ActionResult Welcome(string name, int numTimes=1)
        {
            ViewBag.Title = "Hello " + name;
            ViewBag.numTimes = numTimes;
            return View();
        }

        public ActionResult Index()
        {
            return View();
        }

        /*
        public string Welcome(string name, int ID = 1) // otettu netistä
        {
            return HttpUtility.HtmlEncode("Hello " + name + ", ID is: " + ID);
        }
        */

        public ActionResult MyTestView()
        {
            return View();
        }

 
    }
}