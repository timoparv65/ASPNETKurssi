﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebASPNET452App.Models; // täältä etsitään luokka ja konteksti

namespace WebASPNET452App.Controllers
{
    public class MoviesController : Controller
    {
        private MovieDBContext db = new MovieDBContext();
        /*
        // GET: Movies
        public ActionResult Index()
        {
            return View(db.Movies.ToList()); // hakee tietokannasta mitä tulee
        }
        */
        public ActionResult Index(string movieGendre, string searchString) // kalvo 108
        {

            var GenreLst = new List<string>();

            // orderby d.Gendre => Geren mukaiseen järjestykseen. Kts WikiPedia SQL
            var GendreQry = from d in db.Movies
                            orderby d.Gendre
                            select d.Gendre;

            GenreLst.AddRange(GendreQry.Distinct());
            ViewBag.movieGendre = new SelectList(GenreLst);

            //var searchString = id;
            var movies = from m in db.Movies select m;
   

            if (!String.IsNullOrEmpty(searchString))
            {
                movies = movies.Where(s => s.Title.Contains(searchString)); // kaikki elokuvat listasta, jossa on etsittävä stringi
            }

            if (!string.IsNullOrEmpty(movieGendre))
            {
                movies = movies.Where(x => x.Gendre == movieGendre);
            }

            return View(movies);
        }


        // GET: Movies/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Movie movie = db.Movies.Find(id);
            if (movie == null)
            {
                return HttpNotFound();
            }
            return View(movie); // palautta kyseisen elokuvan
        }

        // GET: Movies/Create
        public ActionResult Create() // luo näytön
        {
            return View();
        }

        // POST: Movies/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,Title,ReleaseDate,Gendre,Price")] Movie movie)
        {
            if (ModelState.IsValid)
            {
                db.Movies.Add(movie);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(movie);
        }

        // GET: Movies/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Movie movie = db.Movies.Find(id);
            if (movie == null)
            {
                return HttpNotFound();
            }
            return View(movie);
        }

        // POST: Movies/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost] // kts kalvo 107
        [ValidateAntiForgeryToken] // kts kalvo 107
        public ActionResult Edit([Bind(Include = "ID,Title,ReleaseDate,Gendre,Price")] Movie movie)
        {
            if (ModelState.IsValid)
            {
                db.Entry(movie).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(movie);
        }

        // GET: Movies/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Movie movie = db.Movies.Find(id);
            if (movie == null)
            {
                return HttpNotFound();
            }
            return View(movie);
        }

        // POST: Movies/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Movie movie = db.Movies.Find(id);
            db.Movies.Remove(movie);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
